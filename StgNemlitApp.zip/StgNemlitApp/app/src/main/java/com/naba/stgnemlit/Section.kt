package com.naba.stgnemlit

import java.io.Serializable

data class Section(
    val id: Int,
    val number: String,
    val title: String,
    val chapter: String,
    val page: Int,
    val body: String
) : Serializable
