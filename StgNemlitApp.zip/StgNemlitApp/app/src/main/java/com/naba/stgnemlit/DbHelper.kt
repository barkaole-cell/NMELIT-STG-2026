package com.naba.stgnemlit

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.io.File
import java.io.FileOutputStream

/**
 * Opens the reference database that is bundled in assets/databases/stg_nemlit.db.
 * The file is copied once into the app's private database directory (SQLite
 * cannot open a database directly out of a compressed asset/APK).
 */
class DbHelper(private val context: Context) {

    companion object {
        private const val DB_NAME = "stg_nemlit.db"
        private const val ASSET_PATH = "databases/stg_nemlit.db"
    }

    private val dbFile: File = context.getDatabasePath(DB_NAME)

    fun openDatabase(): SQLiteDatabase {
        if (!dbFile.exists()) {
            copyFromAssets()
        }
        return SQLiteDatabase.openDatabase(dbFile.path, null, SQLiteDatabase.OPEN_READONLY)
    }

    private fun copyFromAssets() {
        dbFile.parentFile?.mkdirs()
        context.assets.open(ASSET_PATH).use { input ->
            FileOutputStream(dbFile).use { output ->
                input.copyTo(output)
            }
        }
    }

    /**
     * Searches sections by chapter title, chapter/section number, or free text.
     * Number-prefix matches (e.g. "8.9") are ranked first, exact/prefix title
     * matches next, then full-text matches across title/chapter/body.
     */
    fun search(db: SQLiteDatabase, rawQuery: String, limit: Int = 100): List<Section> {
        val query = rawQuery.trim()
        if (query.isEmpty()) return emptyList()

        val results = LinkedHashMap<Int, Section>()

        // 1) Section-number prefix match, e.g. "8.9" or "8.9.3"
        if (query.matches(Regex("^[0-9][0-9.]*$"))) {
            db.rawQuery(
                "SELECT id, number, title, chapter, page, body FROM sections " +
                    "WHERE number LIKE ? ORDER BY length(number), number LIMIT ?",
                arrayOf("$query%", limit.toString())
            ).use { c ->
                while (c.moveToNext()) {
                    val s = c.toSection()
                    results[s.id] = s
                }
            }
        }

        // 2) Title starts-with / contains match (handles partial chapter titles)
        db.rawQuery(
            "SELECT id, number, title, chapter, page, body FROM sections " +
                "WHERE title LIKE ? ORDER BY CASE WHEN title LIKE ? THEN 0 ELSE 1 END, title LIMIT ?",
            arrayOf("%$query%", "$query%", limit.toString())
        ).use { c ->
            while (c.moveToNext()) {
                val s = c.toSection()
                results.putIfAbsent(s.id, s)
            }
        }

        // 3) Full-text search across number, title, chapter, body (prefix match per word)
        val ftsTokens = query.split(Regex("\\s+"))
            .filter { it.isNotBlank() }
            .map { sanitizeToken(it) + "*" }
        if (ftsTokens.isNotEmpty()) {
            val ftsQuery = ftsTokens.joinToString(" ")
            db.rawQuery(
                "SELECT s.id, s.number, s.title, s.chapter, s.page, s.body " +
                    "FROM sections_fts f JOIN sections s ON s.id = f.rowid " +
                    "WHERE sections_fts MATCH ? LIMIT ?",
                arrayOf(ftsQuery, limit.toString())
            ).use { c ->
                while (c.moveToNext()) {
                    val s = c.toSection()
                    results.putIfAbsent(s.id, s)
                }
            }
        }

        return results.values.take(limit).toList()
    }

    private fun sanitizeToken(token: String): String =
        token.replace("\"", "").replace("'", "").replace("*", "")

    private fun android.database.Cursor.toSection(): Section = Section(
        id = getInt(getColumnIndexOrThrow("id")),
        number = getString(getColumnIndexOrThrow("number")) ?: "",
        title = getString(getColumnIndexOrThrow("title")) ?: "",
        chapter = getString(getColumnIndexOrThrow("chapter")) ?: "",
        page = getInt(getColumnIndexOrThrow("page")),
        body = getString(getColumnIndexOrThrow("body")) ?: ""
    )
}
