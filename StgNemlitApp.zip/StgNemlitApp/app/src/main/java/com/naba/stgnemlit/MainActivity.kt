package com.naba.stgnemlit

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.naba.stgnemlit.databinding.ActivityMainBinding
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var dbHelper: DbHelper
    private var database: SQLiteDatabase? = null
    private lateinit var adapter: ResultsAdapter

    private val mainHandler = Handler(Looper.getMainLooper())
    private var searchRunnable: Runnable? = null
    private val debounceMs = 200L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = ResultsAdapter { section ->
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra(DetailActivity.EXTRA_SECTION, section)
            startActivity(intent)
        }
        binding.recyclerResults.layoutManager = LinearLayoutManager(this)
        binding.recyclerResults.adapter = adapter
        binding.recyclerResults.addItemDecoration(
            DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
        )

        dbHelper = DbHelper(this)

        // Open the (potentially first-time-copied) database off the main thread.
        binding.progress.visibility = android.view.View.VISIBLE
        thread {
            val db = dbHelper.openDatabase()
            mainHandler.post {
                database = db
                binding.progress.visibility = android.view.View.GONE
                binding.textHint.visibility = android.view.View.VISIBLE
            }
        }

        binding.editSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                searchRunnable?.let { mainHandler.removeCallbacks(it) }
                val query = s?.toString().orEmpty()
                val runnable = Runnable { performSearch(query) }
                searchRunnable = runnable
                mainHandler.postDelayed(runnable, debounceMs)
            }
        })
    }

    private fun performSearch(query: String) {
        val db = database ?: return
        if (query.isBlank()) {
            adapter.submitList(emptyList())
            binding.textHint.visibility = android.view.View.VISIBLE
            binding.textEmpty.visibility = android.view.View.GONE
            return
        }
        binding.textHint.visibility = android.view.View.GONE
        thread {
            val results = try {
                dbHelper.search(db, query)
            } catch (e: Exception) {
                emptyList()
            }
            mainHandler.post {
                adapter.submitList(results)
                binding.textEmpty.visibility =
                    if (results.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        database?.close()
    }
}
