package com.naba.stgnemlit

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.naba.stgnemlit.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_SECTION = "extra_section"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }

        @Suppress("DEPRECATION")
        val section = intent.getSerializableExtra(EXTRA_SECTION) as? Section ?: run {
            finish()
            return
        }

        binding.toolbar.title = section.number
        binding.textTitle.text = section.title
        binding.textChapter.text = section.chapter.ifBlank { "Page ${section.page}" }
        binding.textPage.text = "Page ${section.page}"
        binding.textBody.text = section.body
    }
}
