package com.naba.stgnemlit

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.naba.stgnemlit.databinding.ItemResultBinding

class ResultsAdapter(
    private val onClick: (Section) -> Unit
) : RecyclerView.Adapter<ResultsAdapter.ResultViewHolder>() {

    private val items = mutableListOf<Section>()

    fun submitList(newItems: List<Section>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ResultViewHolder {
        val binding = ItemResultBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ResultViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ResultViewHolder, position: Int) {
        holder.bind(items[position], onClick)
    }

    override fun getItemCount(): Int = items.size

    class ResultViewHolder(private val binding: ItemResultBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(section: Section, onClick: (Section) -> Unit) {
            binding.textNumber.text = section.number
            binding.textTitle.text = section.title
            binding.textChapter.text = section.chapter.ifBlank { "Page ${section.page}" }
            binding.root.setOnClickListener { onClick(section) }
        }
    }
}
