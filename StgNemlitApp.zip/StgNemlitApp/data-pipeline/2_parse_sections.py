import re, json

with open('raw_pages.txt', encoding='utf-8') as f:
    raw = f.read()

# split into pages
page_chunks = re.split(r'\n<<<PAGE (\d+)>>>\n', raw)[1:]  # first elem empty before first marker
pages = []  # list of (page_index, text)
for i in range(0, len(page_chunks), 2):
    idx = int(page_chunks[i])
    text = page_chunks[i+1]
    pages.append((idx, text))

chapter_re = re.compile(r'^CHAPTER\s+[A-Z\-]+\s*$')
section_re = re.compile(r'^(\d+(?:\.\d+){0,4})\s+([A-Z][^\n]{1,140})$')

sections = []
current_chapter = None
current = None  # dict for current section being built

def flush():
    global current
    if current is not None:
        current['text'] = current['text'].strip()
        if current['text']:
            sections.append(current)
    current = None

for page_idx, text in pages:
    if page_idx < 33:
        continue
    lines = text.split('\r\n') if '\r\n' in text else text.split('\n')
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line:
            i += 1
            continue
        # skip lone page-number lines
        if re.match(r'^\d{1,4}$', line) and len(line) <= 4:
            i += 1
            continue
        if chapter_re.match(line):
            # next non-empty line = chapter title
            j = i+1
            title_line = ''
            while j < len(lines):
                if lines[j].strip():
                    title_line = lines[j].strip()
                    break
                j += 1
            current_chapter = f"{line.title()}: {title_line.title()}"
            i = j+1
            continue
        m = section_re.match(line)
        if m:
            flush()
            current = {
                'number': m.group(1),
                'title': m.group(2).strip(),
                'chapter': current_chapter,
                'page_start': page_idx + 1,  # human 1-indexed
                'text': ''
            }
            i += 1
            continue
        # regular content line
        if current is not None:
            current['text'] += line + '\n'
        i += 1

flush()

print("total sections found:", len(sections))
print(json.dumps(sections[:5], indent=2)[:2000])

with open('sections.json','w') as f:
    json.dump(sections, f, ensure_ascii=False)
