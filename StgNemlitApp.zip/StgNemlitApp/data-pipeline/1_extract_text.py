import pypdfium2 as pdfium
import time

path = '/mnt/user-data/uploads/STG-NEMLIT_7TH_EDITION_2026_-__Final_Version_August_2026.pdf'
pdf = pdfium.PdfDocument(path)
n = len(pdf)
print("pages", n, flush=True)
t0=time.time()
with open('raw_pages.txt','w') as f:
    for i in range(n):
        page = pdf[i]
        textpage = page.get_textpage()
        t = textpage.get_text_range()
        f.write(f"\n<<<PAGE {i}>>>\n")
        f.write(t)
        textpage.close()
        page.close()
        if i % 100 == 0:
            print("done", i, time.time()-t0, flush=True)
print("DONE", time.time()-t0)
