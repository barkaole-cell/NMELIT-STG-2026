"""Builds app/src/main/assets/databases/stg_nemlit.db from sections.json.
Run this after 1_extract_text.py and 2_parse_sections.py have produced
raw_pages.txt and sections.json in this same folder.
"""
import json, sqlite3, os

sections = json.load(open('sections.json'))
db_path = '../app/src/main/assets/databases/stg_nemlit.db'
if os.path.exists(db_path):
    os.remove(db_path)

conn = sqlite3.connect(db_path)
cur = conn.cursor()
cur.execute('''CREATE TABLE sections (
    id INTEGER PRIMARY KEY, number TEXT, title TEXT, chapter TEXT, page INTEGER, body TEXT
)''')
cur.execute('''CREATE VIRTUAL TABLE sections_fts USING fts4(
    number, title, chapter, body, content="sections"
)''')
for i, s in enumerate(sections):
    cur.execute(
        "INSERT INTO sections (id, number, title, chapter, page, body) VALUES (?,?,?,?,?,?)",
        (i, s['number'], s['title'], s['chapter'] or '', s['page_start'], s['text'])
    )
cur.execute("INSERT INTO sections_fts(rowid, number, title, chapter, body) "
            "SELECT id, number, title, chapter, body FROM sections")
conn.commit()
conn.close()
print("Built", db_path)
