# STG-NEMLIT Search App

A lightweight Android app that lets you instantly search the STG-NEMLIT 7th
Edition (2026) by chapter title, section number, or any word, and open a
clean reading view of that section.

The PDF (778 pages) has already been parsed into **1,121 searchable
sections** and packed into a SQLite full-text-search database
(`app/src/main/assets/databases/stg_nemlit.db`, ~4 MB), so the app works
fully offline — no re-parsing happens on the device.

## 1. Prerequisites (one-time, on your computer)

- **Android Studio** (easiest — it bundles the JDK, SDK, and Gradle) from
  https://developer.android.com/studio, OR
- Command-line only: JDK 17, the Android command-line tools, and Gradle 8.7.

## 2. Open / build the project

### Option A — Android Studio (recommended)
1. `File > Open`, select the `StgNemlitApp` folder.
2. Let it sync (it will generate the Gradle wrapper automatically).
3. Click **Run ▶** with a device/emulator connected.

### Option B — pure terminal
```bash
cd StgNemlitApp

# Generate the Gradle wrapper (only needed once, if you have Gradle installed)
gradle wrapper --gradle-version 8.7

# Build a debug APK
./gradlew assembleDebug

# Install it on a connected device/emulator
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
If you don't have Gradle installed, download it once from
https://gradle.org/releases/ (or just use Android Studio, which never
requires this step).

## 3. Rebuilding the database from a new/updated PDF

The `data-pipeline/` folder contains the exact scripts used to turn the PDF
into the app's database, in order:

```bash
cd data-pipeline

# 1) Extract raw text per page from the PDF (uses pypdfium2 — fast, low memory)
pip install pypdfium2
python3 1_extract_text.py    # writes raw_pages.txt

# 2) Parse the text into numbered sections (chapter, number, title, body)
python3 2_parse_sections.py  # writes sections.json

# 3) Rebuild the SQLite FTS database used by the app
python3 3_build_db.py        # writes ../app/src/main/assets/databases/stg_nemlit.db
```
Edit the `path` variable at the top of `1_extract_text.py` to point at your
PDF file, then rerun the three scripts and rebuild the app.

## How it works

- **Parsing** (`2_parse_sections.py`): scans each page for `CHAPTER …`
  headings and numbered section headings (e.g. `8.9.3 Cluster headache`),
  and groups the text under each heading into a section record with its
  chapter, number, title, and starting page.
- **Database**: an SQLite FTS4 virtual table indexes `number`, `title`,
  `chapter`, and `body` for instant prefix/word search.
- **App** (`MainActivity` + `DbHelper`): the search box debounces keystrokes
  by 200ms, then queries in priority order — section-number prefix match,
  then title match, then full-text match — and shows results in a list.
  Tapping a result opens `DetailActivity`, a distraction-free reading view
  with the section number, title, chapter, page, and full text.
- The bundled `.db` is copied from `assets/` into the app's private storage
  on first launch (SQLite can't query a file still sitting inside the
  compressed APK/assets).

## Known limitations

- Section detection is heuristic (regex-based), so a handful of headings
  with unusual formatting may be mis-titled or merged with a neighbor —
  spot-check anything mission-critical against the original PDF.
- Tables in the PDF (e.g. the NEMLIT medicine list) are extracted as plain
  text, so column alignment isn't preserved in the reading view.
